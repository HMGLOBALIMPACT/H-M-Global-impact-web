
// Keep the primary navigation visually and semantically aligned with the current page.
(function(){
  const current = document.body?.dataset?.page || (location.pathname.replace(/\/$/, '').split('/').pop() || 'home');
  const key = current === 'home' ? '/' : '/' + current;
  document.querySelectorAll('.nav a').forEach(a => {
    const href = new URL(a.getAttribute('href') || '', location.href).pathname.replace(/\/$/, '') || '/';
    const normalized = href === '' ? '/' : href;
    const active = normalized === key || (key === '/' && normalized === '/');
    a.classList.toggle('active', active);
    if (active) a.setAttribute('aria-current','page');
    else a.removeAttribute('aria-current');
  });
})();

const menu = document.querySelector('.menu-toggle');
const navEl = document.querySelector('.nav');
if (menu && navEl) {
  menu.addEventListener('click', () => {
    const open = navEl.classList.toggle('open');
    menu.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  navEl.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navEl.classList.remove('open')));
}

document.querySelectorAll('#year').forEach(el => el.textContent = new Date().getFullYear());

const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, {threshold: 0.12});
  revealItems.forEach(el => observer.observe(el));
} else {
  revealItems.forEach(el => el.classList.add('is-visible'));
}

const slides = [...document.querySelectorAll('.hero-slide')];
const dots = [...document.querySelectorAll('.slider-dots button')];
if (slides.length) {
  let current = 0;
  const showSlide = index => {
    current = (index + slides.length) % slides.length;
    slides.forEach((s,i) => s.classList.toggle('is-active', i === current));
    dots.forEach((d,i) => d.classList.toggle('active', i === current));
  };
  dots.forEach((d,i) => d.addEventListener('click', () => showSlide(i)));
  setInterval(() => showSlide(current + 1), 5200);
}
// HM Global Impact — reliable appliance-based preliminary solar planner
(function(){
  const form=document.getElementById('energyPlanner');
  const rows=document.getElementById('applianceRows');
  const result=document.getElementById('plannerResult');
  const addBtn=document.getElementById('addAppliance');
  const resetBtn=document.getElementById('resetPlanner');
  const backup=document.getElementById('backupDays');
  if(!form||!rows||!result||!addBtn||!backup) return;

  const esc=v=>String(v||'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  function rowTemplate(name='',qty=1,watts='',hours=''){
    const row=document.createElement('div');
    row.className='appliance-row';
    row.innerHTML=`<label><span>Appliance</span><input class="appliance-name" type="text" placeholder="e.g. TV" aria-label="Appliance name" value="${esc(name)}"></label>
      <label><span>Quantity</span><input class="appliance-qty" type="number" min="1" step="1" value="${qty}" aria-label="Quantity"></label>
      <label><span>Watts</span><input class="appliance-watts" type="number" min="1" step="1" value="${watts}" aria-label="Watts per appliance"></label>
      <label><span>Hours/day</span><input class="appliance-hours" type="number" min="0.1" max="24" step="0.5" value="${hours}" aria-label="Hours per day"></label>
      <button class="remove-appliance" type="button" aria-label="Remove appliance">×</button>`;
    return row;
  }

  function addRow(){
    const row=rowTemplate();
    rows.appendChild(row);
    row.querySelector('.appliance-name').focus();
  }
  // Start with one practical example so the calculator is never visually empty.
  if(!rows.children.length) rows.appendChild(rowTemplate('TV',1,120,5));

  function removeRow(button){
    if(rows.children.length===1){
      rows.firstElementChild.querySelector('.appliance-name').value='';
      rows.firstElementChild.querySelector('.appliance-watts').value='';
      rows.firstElementChild.querySelector('.appliance-hours').value='';
      rows.firstElementChild.querySelector('.appliance-qty').value='1';
      result.innerHTML='Enter at least one appliance, then tap <strong>Calculate Preliminary Size</strong>.';
      return;
    }
    button.closest('.appliance-row').remove();
  }

  function calculate(){
    const items=[...rows.querySelectorAll('.appliance-row')].map(row=>({
      name:row.querySelector('.appliance-name').value.trim()||'Unnamed appliance',
      qty:Math.max(1,Number(row.querySelector('.appliance-qty').value)||1),
      watts:Math.max(0,Number(row.querySelector('.appliance-watts').value)||0),
      hours:Math.min(24,Math.max(0,Number(row.querySelector('.appliance-hours').value)||0))
    })).filter(x=>x.watts>0&&x.hours>0);

    if(!items.length){
      result.innerHTML='<strong>Please enter appliance wattage and hours.</strong><br>For example: TV • 1 unit • 120 W • 5 hours/day.';
      return false;
    }

    const backupDays=Math.min(7,Math.max(.5,Number(backup.value)||1));
    const peakW=items.reduce((sum,x)=>sum+(x.qty*x.watts),0);
    const dailyWh=items.reduce((sum,x)=>sum+(x.qty*x.watts*x.hours),0);
    const inverter=Math.max(500,Math.ceil((peakW*1.25)/100)*100);
    const pv=Math.max(300,Math.ceil((dailyWh/(4.5*0.78))/100)*100);
    const batteryWh=dailyWh*backupDays/0.85;
    const batteryKwh=batteryWh/1000;
    const batteryAh48=batteryWh/48;
    const itemSummary=items.map(x=>`${x.qty} × ${esc(x.name)} (${Math.round(x.watts*x.hours*x.qty).toLocaleString()} Wh/day)`).join(' • ');

    result.innerHTML=`<strong>Preliminary estimate</strong>
      <div class="planner-result-grid">
        <span><b>Daily energy</b>${Math.round(dailyWh).toLocaleString()} Wh/day</span>
        <span><b>Running load</b>${Math.round(peakW).toLocaleString()} W</span>
        <span><b>Inverter starting point</b>about ${inverter.toLocaleString()} W</span>
        <span><b>PV starting point</b>about ${pv.toLocaleString()} W</span>
        <span><b>Battery storage</b>about ${batteryKwh.toFixed(1)} kWh</span>
        <span><b>48 V equivalent</b>about ${Math.round(batteryAh48).toLocaleString()} Ah</span>
      </div>
      <small><b>Loads included:</b> ${itemSummary}</small>
      <small>Preliminary planning only. Final sizing depends on starting surge, actual usage, solar resource, site conditions, battery chemistry, system voltage and installation requirements.</small>`;
    return true;
  }

  rows.addEventListener('click',e=>{ if(e.target.closest('.remove-appliance')) removeRow(e.target.closest('.remove-appliance')); });
  addBtn.addEventListener('click',addRow);
  form.addEventListener('submit',e=>{e.preventDefault();calculate();});
  resetBtn?.addEventListener('click',()=>{
    rows.innerHTML='';
    rows.appendChild(rowTemplate('TV',1,120,5));
    backup.value='1';
    result.innerHTML='Enter your appliances and tap <strong>Calculate Preliminary Size</strong>.';
  });
})();

/* ===== HM Global Impact AI Assistant ===== */
(function(){
  const launcher=document.createElement('button');
  launcher.className='ai-launcher';
  launcher.setAttribute('aria-label','Open HM Global Impact AI assistant');
  launcher.title='HM Global Impact AI Assistant';
  launcher.innerHTML='<span class="ai-orb" aria-hidden="true"><svg viewBox="0 0 64 64" role="img"><rect x="16" y="19" width="32" height="28" rx="9" fill="none" stroke="currentColor" stroke-width="4"/><path d="M32 12v7M25 31h.1M39 31h.1M25 38c4 3 10 3 14 0M12 29h4M48 29h4" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><circle cx="32" cy="9" r="2.5" fill="currentColor"/></svg></span>';
  document.body.appendChild(launcher);

  const panel=document.createElement('section');
  panel.className='ai-panel';
  panel.setAttribute('role','dialog');
  panel.setAttribute('aria-modal','false');
  panel.setAttribute('aria-label','HM Global Impact AI Assistant');
  panel.innerHTML=`<div class="ai-head"><div class="ai-head-brand"><span class="ai-head-orb" aria-hidden="true"><svg viewBox="0 0 64 64"><rect x="16" y="19" width="32" height="28" rx="9" fill="none" stroke="currentColor" stroke-width="4"/><path d="M32 12v7M25 31h.1M39 31h.1M25 38c4 3 10 3 14 0M12 29h4M48 29h4" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><circle cx="32" cy="9" r="2.5" fill="currentColor"/></svg></span><div><strong>HM Global AI Assistant</strong><small>Solar • Electrical • Security</small></div></div><button class="ai-close" aria-label="Close AI assistant">×</button></div><div class="ai-messages" id="aiMessages"><div class="ai-msg bot ai-welcome">Hi 👋</div></div><div class="ai-quick"><button data-q="Tell me about HM Global Impact Limited.">About HM Global</button><button data-q="What solar services does HM Global Impact provide?">Solar services</button><button data-q="What products and equipment can I ask HM Global Impact about?">Products</button><button data-q="Explain the difference between lithium and tubular batteries.">Battery guide</button><button data-q="Help me estimate a solar system for my home.">Solar estimate</button></div><form class="ai-form" id="aiForm"><input id="aiInput" autocomplete="off" placeholder="Ask HM Global AI…"><button type="submit">Send</button></form><div class="ai-handoff" id="aiHandoff" hidden><a href="https://wa.me/2348036139930" target="_blank" rel="noopener"><span class="wa-mini-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path fill="currentColor" d="M20.5 3.5A11.8 11.8 0 0 0 12.1 0C5.6 0 .3 5.3.3 11.8c0 2.1.6 4.1 1.6 5.9L0 24l6.5-1.7a11.8 11.8 0 0 0 5.6 1.4h.1c6.5 0 11.8-5.3 11.8-11.8 0-3.2-1.2-6.2-3.5-8.4ZM12.1 21.7h-.1a9.8 9.8 0 0 1-5-1.4l-.4-.2-3.9 1 1-3.8-.3-.4a9.7 9.7 0 0 1-1.5-5.2c0-5.4 4.4-9.8 9.8-9.8 2.6 0 5.1 1 6.9 2.9a9.7 9.7 0 0 1 2.9 6.9c0 5.5-4.4 10-9.8 10Zm5.4-7.3c-.3-.2-1.7-.8-2-.9-.3-.1-.5-.2-.7.2-.2.3-.8.9-1 .1.1-.1.2-.1.4-.1.1-.1.1-.2.2-.3.1-.2.1-.3 0-.5-.1-.2-.7-1.7-1-2.3-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1.1 1.1-1.1 2.6s1.1 3 1.3 3.2c.2.2 2.2 3.4 5.4 4.6.8.3 1.4.5 1.9.6.8.2 1.5.2 2 .1.6-.1 1.7-.7 2-1.4.2-.7.2-1.3.1-1.4-.1-.1-.3-.2-.6-.3Z"/></svg></span>Continue on WhatsApp</a></div><div class="ai-disclaimer">AI guidance is informational. Current stock, pricing and final engineering decisions must be confirmed by HM Global Impact.</div>`;
  document.body.appendChild(panel);

  const messages=panel.querySelector('#aiMessages'), input=panel.querySelector('#aiInput'), handoff=panel.querySelector('#aiHandoff');
  const history=[];
  function cleanAIText(text){
    return String(text||'').replace(/\[([^\]]+)\]\(([^)]+)\)/g,'$1').replace(/^\s*#{1,6}\s*/gm,'').replace(/\*\*([^*]+)\*\*/g,'$1').replace(/__([^_]+)__/g,'$1').replace(/\*([^*]+)\*/g,'$1').replace(/`([^`]+)`/g,'$1').replace(/^\s*[-*]\s+/gm,'• ').replace(/\n{3,}/g,'\n\n').trim();
  }
  function add(text,who='bot',save=true){
    text=who==='bot'?cleanAIText(text):String(text);
    const d=document.createElement('div');
    d.className='ai-msg '+who;
    d.textContent=text;
    messages.appendChild(d);
    messages.scrollTop=messages.scrollHeight;
    if(save) history.push({role:who==='user'?'user':'assistant',content:text});
  }
  function showHandoff(show){ handoff.hidden=!show; }
  async function ask(q){
    const prior=history.slice(-10);
    add(q,'user'); input.value=''; showHandoff(false);
    const thinking=document.createElement('div');
    thinking.className='ai-msg bot';
    thinking.textContent='Thinking…';
    messages.appendChild(thinking); messages.scrollTop=messages.scrollHeight;
    try{
      const r=await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message:q,history:prior})});
      const data=await r.json().catch(()=>({}));
      if(!r.ok || !data.answer) throw new Error(data.error||'AI endpoint unavailable');
      thinking.remove();
      add(data.answer);
      showHandoff(Boolean(data.handoff));
    }catch(e){
      thinking.remove();
      const ql=q.toLowerCase();
      let a='I can help with HM Global Impact’s solar, electrical and security services. Tell me what you are trying to power, install, protect or buy, and I’ll guide you through the next step.';
      if(/battery|lithium|tubular|gel/.test(ql)) a='Lithium batteries generally provide higher usable energy density, faster charging and deeper cycling, while tubular lead-acid batteries are a more established lower-cost option but are heavier and normally require more operating care. The right choice depends on your load, backup time, budget, charging profile and system voltage.';
      else if(/inverter|ups|backup/.test(ql)) a='An inverter converts DC electricity from batteries or another DC source into AC electricity for compatible loads. For a solar/backup system, the correct inverter size depends on running load, starting surge, battery voltage, desired backup time and the loads you intend to operate.';
      else if(/panel|solar|pv|sun/.test(ql)) a='HM Global Impact works with solar PV modules, inverters, batteries and charge controllers, and provides system design, installation, maintenance and repairs. If you tell me your main appliances, approximate wattage and desired backup hours, I can help you make a preliminary estimate.';
      else if(/cctv|camera|security|fence/.test(ql)) a='HM Global Impact provides CCTV/security solutions and electric-fence/security-wire installation and maintenance. I can explain how these systems work or help you prepare the information needed for a quotation.';
      else if(/price|cost|quote|quotation|buy|purchase|stock|available/.test(ql)) { a='I can help you identify the equipment and information you need. For a live quotation, HM Global Impact needs the exact model/specification and current stock position, so the safest next step is WhatsApp. I can also help you prepare the enquiry before you send it.'; showHandoff(true); }
      else if(/contact|phone|address|location|lagos|ibadan|email/.test(ql)) { a='HM Global Impact can be reached on +234 803 613 9930 (call/WhatsApp) or info@hmglobalimpact.com. Lagos: 12 Osolo Way, Ajao Estate, Isolo, Lagos State. Ibadan: 120 Ifesowapo Oleyo Street, From Tipper Garage, Ibadan, Oyo State.'; }
      add(a);
    }
  }
  function openAssistant(){ panel.classList.add('open'); launcher.classList.add('active'); panel.setAttribute('aria-modal','true'); setTimeout(()=>input.focus(),120); }
  function closeAssistant(){ panel.classList.remove('open'); launcher.classList.remove('active'); panel.setAttribute('aria-modal','false'); launcher.focus(); }
  launcher.addEventListener('click',()=>{ panel.classList.contains('open') ? closeAssistant() : openAssistant(); });
  panel.querySelector('.ai-close').addEventListener('click',closeAssistant);
  panel.querySelectorAll('.ai-quick button').forEach(b=>b.addEventListener('click',()=>ask(b.dataset.q)));
  panel.querySelector('#aiForm').addEventListener('submit',e=>{e.preventDefault();const q=input.value.trim();if(q)ask(q)});
  // Keep the AI launcher visible without forcing the chat panel open on page load.

})();

/* ===== Draggable floating AI + WhatsApp controls ===== */
(function(){
  const controls=[document.querySelector('.ai-launcher'),document.querySelector('.floating-wa')].filter(Boolean);
  controls.forEach(el=>{
    let startX=0,startY=0,startLeft=0,startTop=0,moved=false,pointerId=null;
    el.addEventListener('pointerdown',e=>{
      if(e.button!==undefined&&e.button!==0) return;
      pointerId=e.pointerId; moved=false; startX=e.clientX; startY=e.clientY;
      const r=el.getBoundingClientRect(); startLeft=r.left; startTop=r.top;
      el.classList.add('dragging'); el.setPointerCapture?.(pointerId);
    });
    el.addEventListener('pointermove',e=>{
      if(pointerId!==e.pointerId) return;
      const dx=e.clientX-startX,dy=e.clientY-startY;
      if(Math.abs(dx)+Math.abs(dy)>5)moved=true;
      if(!moved)return;
      const maxX=Math.max(8,window.innerWidth-el.offsetWidth-8),maxY=Math.max(8,window.innerHeight-el.offsetHeight-8);
      const left=Math.min(maxX,Math.max(8,startLeft+dx)),top=Math.min(maxY,Math.max(8,startTop+dy));
      el.style.left=left+'px'; el.style.top=top+'px'; el.style.right='auto'; el.style.bottom='auto';
      e.preventDefault();
    });
    el.addEventListener('pointerup',e=>{
      if(pointerId!==e.pointerId)return;
      el.classList.remove('dragging');
      try{el.releasePointerCapture?.(pointerId)}catch(_){}
      pointerId=null;
      if(moved){el.dataset.dragged='1';setTimeout(()=>delete el.dataset.dragged,80);}
    });
    el.addEventListener('click',e=>{if(el.dataset.dragged==='1'){e.preventDefault();e.stopImmediatePropagation();}} ,true);
  });
})();

/* ===== PWA registration + install prompt ===== */
(function(){
  if('serviceWorker' in navigator){
    window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js?v=10').catch(()=>{}));
  }
  let deferredPrompt=null;
  const isStandalone=window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone===true;
  window.addEventListener('beforeinstallprompt',e=>{
    e.preventDefault();
    deferredPrompt=e;
    if(isStandalone || sessionStorage.getItem('hmInstallDismissed')==='1') return;
    setTimeout(()=>{
      if(document.querySelector('.install-card') || !deferredPrompt) return;
      const card=document.createElement('aside');
      card.className='install-card';
      card.innerHTML='<div class="install-icon"><img src="assets/hm-global-app-192.png" alt="HM Global"></div><div class="install-copy"><strong>Install HM Global</strong><span>Keep HM Global Impact one tap away on your phone.</span></div><button class="install-now">Install</button><button class="install-close" aria-label="Dismiss install prompt">×</button>';
      document.body.appendChild(card);
      card.querySelector('.install-now').addEventListener('click',async()=>{ if(!deferredPrompt) return; deferredPrompt.prompt(); await deferredPrompt.userChoice.catch(()=>{}); deferredPrompt=null; card.remove(); });
      card.querySelector('.install-close').addEventListener('click',()=>{sessionStorage.setItem('hmInstallDismissed','1');card.remove();});
    },1800);
  });
  window.addEventListener('appinstalled',()=>{deferredPrompt=null;const card=document.querySelector('.install-card');if(card)card.remove();});
})();

/* Product quote buttons */
document.querySelectorAll('.quote-mini').forEach(btn=>btn.addEventListener('click',()=>{
  const product=btn.dataset.product||'product';
  const msg=encodeURIComponent(`Hello HM Global Impact, I would like to request a quotation for ${product}. Please share current price, available models/specification and delivery/installation options.`);
  window.open('https://wa.me/2348036139930?text='+msg,'_blank','noopener');
}));

/* Back-to-top control */
(function(){const b=document.createElement('button');b.className='backtop';b.textContent='↑';b.setAttribute('aria-label','Back to top');document.body.appendChild(b);window.addEventListener('scroll',()=>b.classList.toggle('show',scrollY>600));b.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));})();

/* Contact enquiry confirmation */
(function(){
  if(location.pathname === '/contact' && new URLSearchParams(location.search).get('submitted') === '1'){
    const box=document.getElementById('enquirySuccess');
    if(box) box.hidden=false;
  }
})();
