
// Keep the primary navigation visually and semantically aligned with the current page.
(function(){
  const current = document.body?.dataset?.page || (location.pathname.replace(/\/$/, '').split('/').pop() || 'home');
  const key = current === 'home' ? '/' : '/' + current;
  document.querySelectorAll('.nav a').forEach(a => {
    const href = new URL(a.getAttribute('href') || '', location.href).pathname.replace(/\/$/, '') || '/';
    const normalized = href === '' ? '/' : href;
    const active = normalized === key || (key === '/' && normalized === '/');
    a.classList.toggle('active', active);
    if (active) a.setAttribute('aria-current','page');
    else a.removeAttribute('aria-current');
  });
})();

const menu = document.querySelector('.menu-toggle');
const navEl = document.querySelector('.nav');
if (menu && navEl) {
  menu.addEventListener('click', () => {
    const open = navEl.classList.toggle('open');
    menu.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  navEl.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navEl.classList.remove('open')));
}

document.querySelectorAll('#year').forEach(el => el.textContent = new Date().getFullYear());

const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, {threshold: 0.12});
  revealItems.forEach(el => observer.observe(el));
} else {
  revealItems.forEach(el => el.classList.add('is-visible'));
}

const slides = [...document.querySelectorAll('.hero-slide')];
const dots = [...document.querySelectorAll('.slider-dots button')];
if (slides.length) {
  let current = 0;
  const showSlide = index => {
    current = (index + slides.length) % slides.length;
    slides.forEach((s,i) => s.classList.toggle('is-active', i === current));
    dots.forEach((d,i) => d.classList.toggle('active', i === current));
  };
  dots.forEach((d,i) => d.addEventListener('click', () => showSlide(i)));
  setInterval(() => showSlide(current + 1), 5200);
}
// HM Global Impact — preliminary smart energy planner
(function(){
  const form=document.getElementById('energyPlanner');
  const result=document.getElementById('plannerResult');
  if(!form||!result) return;
  form.addEventListener('submit',function(e){
    e.preventDefault();
    const load=Math.max(100,Number(document.getElementById('loadW').value)||1000);
    const hours=Math.min(24,Math.max(1,Number(document.getElementById('hoursDay').value)||5));
    const days=Math.min(3,Math.max(.5,Number(document.getElementById('backupDays').value)||1));
    const dailyWh=load*hours;
    const inverter=Math.ceil((load*1.25)/100)*100;
    const pv=Math.ceil((dailyWh/(4.5*0.78))/100)*100;
    const batteryWh=dailyWh*days/0.85;
    const batteryKwh=(batteryWh/1000).toFixed(1);
    result.innerHTML='<strong>Preliminary estimate</strong><br>Daily energy: '+Math.round(dailyWh).toLocaleString()+' Wh<br>Suggested inverter class: about '+inverter.toLocaleString()+' W<br>PV array: about '+pv.toLocaleString()+' W<br>Battery storage: about '+batteryKwh+' kWh<br><small>Final sizing depends on appliance surge, site conditions, battery chemistry, system voltage and installation requirements.</small>';
  });
})();



/* ===== HM Global Impact AI Assistant ===== */
(function(){
  const launcher=document.createElement('button');
  launcher.className='ai-launcher';
  launcher.setAttribute('aria-label','Open HM Global Impact AI assistant');
  launcher.title='HM Global Impact AI Assistant';
  launcher.innerHTML='<span class="ai-orb" aria-hidden="true"><svg viewBox="0 0 64 64" role="img"><rect x="16" y="19" width="32" height="28" rx="9" fill="none" stroke="currentColor" stroke-width="4"/><path d="M32 12v7M25 31h.1M39 31h.1M25 38c4 3 10 3 14 0M12 29h4M48 29h4" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><circle cx="32" cy="9" r="2.5" fill="currentColor"/></svg></span><span class="ai-badge">AI</span>';
  document.body.appendChild(launcher);

  const panel=document.createElement('section');
  panel.className='ai-panel';
  panel.setAttribute('role','dialog');
  panel.setAttribute('aria-modal','false');
  panel.setAttribute('aria-label','HM Global Impact AI Assistant');
  panel.innerHTML=`<div class="ai-head"><div class="ai-head-brand"><span class="ai-head-orb" aria-hidden="true"><svg viewBox="0 0 64 64"><rect x="16" y="19" width="32" height="28" rx="9" fill="none" stroke="currentColor" stroke-width="4"/><path d="M32 12v7M25 31h.1M39 31h.1M25 38c4 3 10 3 14 0M12 29h4M48 29h4" fill="none" stroke="currentColor" stroke-width="4" stroke-linecap="round"/><circle cx="32" cy="9" r="2.5" fill="currentColor"/></svg></span><div><strong>HM Global AI Assistant</strong><small>Solar • Electrical • Security</small></div></div><button class="ai-close" aria-label="Close AI assistant">×</button></div><div class="ai-messages" id="aiMessages"><div class="ai-msg bot ai-welcome"><strong>Hello 👋</strong><br>I'm the HM Global Impact AI Assistant. How can I help you today?</div></div><div class="ai-quick"><button data-q="Tell me about HM Global Impact Limited.">About HM Global</button><button data-q="What solar services does HM Global Impact provide?">Solar services</button><button data-q="What products and equipment can I ask HM Global Impact about?">Products</button><button data-q="Explain the difference between lithium and tubular batteries.">Battery guide</button><button data-q="Help me estimate a solar system for my home.">Solar estimate</button></div><form class="ai-form" id="aiForm"><input id="aiInput" autocomplete="off" placeholder="Ask HM Global AI…"><button type="submit">Send</button></form><div class="ai-handoff" id="aiHandoff" hidden><a href="https://wa.me/2348036139930" target="_blank" rel="noopener"><span class="wa-mini-icon" aria-hidden="true"><svg viewBox="0 0 24 24"><path fill="currentColor" d="M20.5 3.5A11.8 11.8 0 0 0 12.1 0C5.6 0 .3 5.3.3 11.8c0 2.1.6 4.1 1.6 5.9L0 24l6.5-1.7a11.8 11.8 0 0 0 5.6 1.4h.1c6.5 0 11.8-5.3 11.8-11.8 0-3.2-1.2-6.2-3.5-8.4ZM12.1 21.7h-.1a9.8 9.8 0 0 1-5-1.4l-.4-.2-3.9 1 1-3.8-.3-.4a9.7 9.7 0 0 1-1.5-5.2c0-5.4 4.4-9.8 9.8-9.8 2.6 0 5.1 1 6.9 2.9a9.7 9.7 0 0 1 2.9 6.9c0 5.5-4.4 10-9.8 10Zm5.4-7.3c-.3-.2-1.7-.8-2-.9-.3-.1-.5-.2-.7.2-.2.3-.8.9-1 .1.1-.1.2-.1.4-.1.1-.1.1-.2.2-.3.1-.2.1-.3 0-.5-.1-.2-.7-1.7-1-2.3-.3-.6-.5-.5-.7-.5h-.6c-.2 0-.5.1-.8.4-.3.3-1.1 1.1-1.1 2.6s1.1 3 1.3 3.2c.2.2 2.2 3.4 5.4 4.6.8.3 1.4.5 1.9.6.8.2 1.5.2 2 .1.6-.1 1.7-.7 2-1.4.2-.7.2-1.3.1-1.4-.1-.1-.3-.2-.6-.3Z"/></svg></span>Continue on WhatsApp</a></div><div class="ai-disclaimer">AI guidance is informational. Current stock, pricing and final engineering decisions must be confirmed by HM Global Impact.</div>`;
  document.body.appendChild(panel);

  const messages=panel.querySelector('#aiMessages'), input=panel.querySelector('#aiInput'), handoff=panel.querySelector('#aiHandoff');
  const history=[];
  function cleanAIText(text){
    return String(text||'').replace(/\[([^\]]+)\]\(([^)]+)\)/g,'$1').replace(/^\s*#{1,6}\s*/gm,'').replace(/\*\*([^*]+)\*\*/g,'$1').replace(/__([^_]+)__/g,'$1').replace(/\*([^*]+)\*/g,'$1').replace(/`([^`]+)`/g,'$1').replace(/^\s*[-*]\s+/gm,'• ').replace(/\n{3,}/g,'\n\n').trim();
  }
  function add(text,who='bot',save=true){
    text=who==='bot'?cleanAIText(text):String(text);
    const d=document.createElement('div');
    d.className='ai-msg '+who;
    d.textContent=text;
    messages.appendChild(d);
    messages.scrollTop=messages.scrollHeight;
    if(save) history.push({role:who==='user'?'user':'assistant',content:text});
  }
  function showHandoff(show){ handoff.hidden=!show; }
  async function ask(q){
    const prior=history.slice(-10);
    add(q,'user'); input.value=''; showHandoff(false);
    const thinking=document.createElement('div');
    thinking.className='ai-msg bot';
    thinking.textContent='Thinking…';
    messages.appendChild(thinking); messages.scrollTop=messages.scrollHeight;
    try{
      const r=await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message:q,history:prior})});
      const data=await r.json().catch(()=>({}));
      if(!r.ok || !data.answer) throw new Error(data.error||'AI endpoint unavailable');
      thinking.remove();
      add(data.answer);
      showHandoff(Boolean(data.handoff));
    }catch(e){
      thinking.remove();
      const ql=q.toLowerCase();
      let a='I can help with HM Global Impact’s solar, electrical and security services. Tell me what you are trying to power, install, protect or buy, and I’ll guide you through the next step.';
      if(/battery|lithium|tubular|gel/.test(ql)) a='Lithium batteries generally provide higher usable energy density, faster charging and deeper cycling, while tubular lead-acid batteries are a more established lower-cost option but are heavier and normally require more operating care. The right choice depends on your load, backup time, budget, charging profile and system voltage.';
      else if(/inverter|ups|backup/.test(ql)) a='An inverter converts DC electricity from batteries or another DC source into AC electricity for compatible loads. For a solar/backup system, the correct inverter size depends on running load, starting surge, battery voltage, desired backup time and the loads you intend to operate.';
      else if(/panel|solar|pv|sun/.test(ql)) a='HM Global Impact works with solar PV modules, inverters, batteries and charge controllers, and provides system design, installation, maintenance and repairs. If you tell me your main appliances, approximate wattage and desired backup hours, I can help you make a preliminary estimate.';
      else if(/cctv|camera|security|fence/.test(ql)) a='HM Global Impact provides CCTV/security solutions and electric-fence/security-wire installation and maintenance. I can explain how these systems work or help you prepare the information needed for a quotation.';
      else if(/price|cost|quote|quotation|buy|purchase|stock|available/.test(ql)) { a='I can help you identify the equipment and information you need. For a live quotation, HM Global Impact needs the exact model/specification and current stock position, so the safest next step is WhatsApp. I can also help you prepare the enquiry before you send it.'; showHandoff(true); }
      else if(/contact|phone|address|location|lagos|ibadan|email/.test(ql)) { a='HM Global Impact can be reached on +234 803 613 9930 (call/WhatsApp) or info@hmglobalimpact.com. Lagos: 12 Osolo Way, Ajao Estate, Isolo, Lagos State. Ibadan: 120 Ifesowapo Oleyo Street, From Tipper Garage, Ibadan, Oyo State.'; }
      add(a);
    }
  }
  function openAssistant(){ panel.classList.add('open'); launcher.classList.add('active'); panel.setAttribute('aria-modal','true'); setTimeout(()=>input.focus(),120); }
  function closeAssistant(){ panel.classList.remove('open'); launcher.classList.remove('active'); panel.setAttribute('aria-modal','false'); launcher.focus(); }
  launcher.addEventListener('click',()=>{ panel.classList.contains('open') ? closeAssistant() : openAssistant(); });
  panel.querySelector('.ai-close').addEventListener('click',closeAssistant);
  panel.querySelectorAll('.ai-quick button').forEach(b=>b.addEventListener('click',()=>ask(b.dataset.q)));
  panel.querySelector('#aiForm').addEventListener('submit',e=>{e.preventDefault();const q=input.value.trim();if(q)ask(q)});
  // The assistant is intentionally visible on entry so visitors do not have to search for it.
  setTimeout(openAssistant, 700);
})();

/* ===== PWA registration + install prompt ===== */
(function(){
  if('serviceWorker' in navigator){
    window.addEventListener('load',()=>navigator.serviceWorker.register('/sw.js?v=6').catch(()=>{}));
  }
  let deferredPrompt=null;
  const isStandalone=window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone===true;
  window.addEventListener('beforeinstallprompt',e=>{
    e.preventDefault();
    deferredPrompt=e;
    if(isStandalone || sessionStorage.getItem('hmInstallDismissed')==='1') return;
    setTimeout(()=>{
      if(document.querySelector('.install-card') || !deferredPrompt) return;
      const card=document.createElement('aside');
      card.className='install-card';
      card.innerHTML='<div class="install-icon"><img src="assets/hm-global-app-192.png" alt="HM Global"></div><div class="install-copy"><strong>Install HM Global</strong><span>Keep HM Global Impact one tap away on your phone.</span></div><button class="install-now">Install</button><button class="install-close" aria-label="Dismiss install prompt">×</button>';
      document.body.appendChild(card);
      card.querySelector('.install-now').addEventListener('click',async()=>{ if(!deferredPrompt) return; deferredPrompt.prompt(); await deferredPrompt.userChoice.catch(()=>{}); deferredPrompt=null; card.remove(); });
      card.querySelector('.install-close').addEventListener('click',()=>{sessionStorage.setItem('hmInstallDismissed','1');card.remove();});
    },1800);
  });
  window.addEventListener('appinstalled',()=>{deferredPrompt=null;const card=document.querySelector('.install-card');if(card)card.remove();});
})();

/* Product quote buttons */
document.querySelectorAll('.quote-mini').forEach(btn=>btn.addEventListener('click',()=>{
  const product=btn.dataset.product||'product';
  const msg=encodeURIComponent(`Hello HM Global Impact, I would like to request a quotation for ${product}. Please share current price, available models/specification and delivery/installation options.`);
  window.open('https://wa.me/2348036139930?text='+msg,'_blank','noopener');
}));

/* Back-to-top control */
(function(){const b=document.createElement('button');b.className='backtop';b.textContent='↑';b.setAttribute('aria-label','Back to top');document.body.appendChild(b);window.addEventListener('scroll',()=>b.classList.toggle('show',scrollY>600));b.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));})();
