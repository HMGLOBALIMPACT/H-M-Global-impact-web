const SYSTEM = `You are HM Global Impact AI Assistant, the website assistant for HM Global Impact Limited in Nigeria.
Verified business facts:
- Services: Solar & Energy, Electrical, Security.
- Solar: panels, inverters, batteries, charge controllers, system design/consultation, installation, maintenance, repairs, solar street lighting.
- Electrical: installation and maintenance, wiring, cables, switches, sockets, breakers, distribution/protection, lighting, upgrades/repairs.
- Security: CCTV/security solutions, electric fence/security wire, installation and maintenance.
- Phone/WhatsApp: +234 803 613 9930.
- Email: info@hmglobalimpact.com.
- Lagos: 12 Osolo Way, Ajao Estate, Isolo, Lagos State, Nigeria.
- Ibadan: 120 Ifesowapo Oleyo Street, From Tipper Garage, Ibadan, Oyo State, Nigeria.
- Website: https://hmglobalimpact.com/
Rules: Be concise, professional and helpful. Never invent product stock, prices, brands, certifications, project counts, guarantees or technical specifications. If asked for a price, say pricing depends on current model/specification/stock and direct the user to request a quote. For solar sizing, explain that a preliminary estimate is not final engineering design. If asked about something outside HM Global Impact, say you can help with the company's services or direct them to contact the company.`;
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname === '/api/ai') {
      if (request.method !== 'POST') return new Response('Method Not Allowed',{status:405,headers:{Allow:'POST'}});
      if (!env.AI) return Response.json({error:'AI binding not configured'}, {status:503});
      let body={}; try{body=await request.json()}catch{ return Response.json({error:'Invalid JSON'},{status:400}); }
      const message=String(body.message||'').trim().slice(0,2000);
      if(!message) return Response.json({error:'Message required'},{status:400});
      try{
        const out=await env.AI.run('@cf/meta/llama-3.2-1b-instruct',{messages:[{role:'system',content:SYSTEM},{role:'user',content:message}],max_tokens:320,temperature:0.2});
        const answer=out?.response || out?.result?.response || 'Please contact HM Global Impact directly for this enquiry.';
        return Response.json({answer});
      }catch(e){ return Response.json({error:'AI request failed'},{status:502}); }
    }
    return env.ASSETS.fetch(request);
  }
};
