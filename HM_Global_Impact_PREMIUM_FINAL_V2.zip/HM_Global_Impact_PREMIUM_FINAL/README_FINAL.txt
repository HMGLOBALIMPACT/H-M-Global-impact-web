HM GLOBAL IMPACT — PREMIUM FINAL WEBSITE

This package contains the production website plus a Cloudflare Workers AI backend.

Website files are in ./public
Worker API is ./src/index.js
Configuration is ./wrangler.jsonc

IMPORTANT: The AI assistant requires a Cloudflare Workers AI binding named AI. The binding is declared in wrangler.jsonc. Cloudflare currently provides a daily free Workers AI allocation; usage above the free allocation requires the applicable Workers Paid plan.

Deploy as a full-stack Worker (static assets + Worker script), not as a static-assets-only upload.

The site deliberately uses “Request Quote” instead of invented prices. Replace those labels with real prices only after you provide the current price list/stock.
