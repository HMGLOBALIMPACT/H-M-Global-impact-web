HM GLOBAL IMPACT LIMITED — FINAL LAUNCH PACKAGE

This package is the production-ready website build for HM Global Impact Limited.

INCLUDED
- Premium multi-page corporate website
- Clean HM Global logo and dedicated app icons
- Responsive mobile/desktop layout
- Solar, Electrical and Security solution pages
- Commercial Product Centre with Request Quote workflow
- WhatsApp enquiry buttons
- Preliminary solar energy planner
- HM Global AI Assistant powered by Cloudflare Workers AI when the AI binding is available
- Deterministic technical guidance fallback so common questions remain useful if AI is temporarily unavailable
- Conversation history for the AI assistant
- AI handoff to WhatsApp for live quotation/stock/purchase/site-specific needs
- Progressive Web App manifest, service worker and install prompt
- Android/iOS browser icon assets
- robots.txt and sitemap.xml
- Security response headers

CLOUDFLARE
Worker name: h-m-global-impact-web
AI binding name: AI
Assets binding: ASSETS

CURRENT GITHUB BUILD COMMAND
unzip -o HM_Global_Impact_PREMIUM_FINAL_LAUNCH.zip && cp -R HM_Global_Impact_PREMIUM_FINAL/. . && sed -i 's/"name": "red-frost-3947"/"name": "h-m-global-impact-web"/' wrangler.jsonc

DEPLOYMENT ORDER
1. Replace the previous ZIP in GitHub with this ZIP.
2. Confirm the Cloudflare build command above.
3. Let Cloudflare build and deploy.
4. Test the temporary workers.dev URL: all pages, AI, WhatsApp links and installation prompt.
5. Add the custom domain hmglobalimpact.com to the Worker using Cloudflare Custom Domains.
6. Verify both hmglobalimpact.com and www.hmglobalimpact.com, including HTTPS and redirects.
7. After the custom domain works, optionally redirect/disable the workers.dev public URL so the company presents one canonical web address.

IMPORTANT
- Do not publish invented prices, stock levels, certifications, project counts or guarantees.
- Final solar sizing remains an engineering/site-assessment decision.
- The AI assistant should answer educational and service questions before escalating to HM Global Impact.
