const SYSTEM = `You are HM Global Impact AI Assistant, the official website assistant for HM Global Impact Limited in Nigeria.
Verified business facts:
- Services: Solar & Energy, Electrical, Security.
- Solar: panels, inverters, batteries, charge controllers, system design/consultation, installation, maintenance, repairs, solar street lighting.
- Electrical: installation and maintenance, wiring, cables, switches, sockets, breakers, distribution/protection, lighting, upgrades/repairs.
- Security: CCTV/security solutions, electric fence/security wire, installation and maintenance.
- Phone/WhatsApp: +234 803 613 9930.
- Email: info@hmglobalimpact.com.
- Lagos: 12 Osolo Way, Ajao Estate, Isolo, Lagos State, Nigeria.
- Ibadan: 120 Ifesowapo Oleyo Street, From Tipper Garage, Ibadan, Oyo State, Nigeria.
- Website: https://hmglobalimpact.com/
Conversation rules:
- Be concise, professional, commercially useful and easy to understand.
- Answer only from the verified facts above plus general technical knowledge when the user asks a general educational question.
- Never invent product stock, prices, brands, certifications, project counts, guarantees or exact technical specifications for HM Global Impact.
- For pricing or availability, say the exact model/specification/current stock must be confirmed and invite the visitor to request a quotation.
- For solar sizing, explain that any website estimate is preliminary and final sizing requires actual loads, usage pattern, surge requirements, site conditions, battery chemistry, system voltage and installation requirements.
- If the user wants to buy, install, repair or request a quotation, make the next step clear: call/WhatsApp +234 803 613 9930 or email info@hmglobalimpact.com.
- Do not claim to be a human employee. You are the website AI assistant.
- If asked something unrelated to HM Global Impact, answer briefly when it is a harmless general question, then connect it back to the company's relevant services where appropriate. Do not pretend the company provides services that are not listed above.`;

const JSON_HEADERS = { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' };
function json(data, status = 200) { return new Response(JSON.stringify(data), { status, headers: JSON_HEADERS }); }

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname === '/api/ai') {
      if (request.method === 'OPTIONS') {
        return new Response(null, { status: 204, headers: { 'access-control-allow-origin': '*', 'access-control-allow-methods': 'POST, OPTIONS', 'access-control-allow-headers': 'content-type' } });
      }
      if (request.method !== 'POST') return new Response('Method Not Allowed', { status: 405, headers: { Allow: 'POST, OPTIONS' } });
      if (!env.AI) return json({ error: 'AI service is not configured yet.' }, 503);

      let body;
      try { body = await request.json(); } catch { return json({ error: 'Invalid JSON.' }, 400); }
      const message = String(body?.message || '').trim().slice(0, 2000);
      if (!message) return json({ error: 'Message required.' }, 400);

      const history = Array.isArray(body?.history) ? body.history.slice(-8).map(item => ({
        role: item?.role === 'user' ? 'user' : 'assistant',
        content: String(item?.content || '').trim().slice(0, 1200)
      })).filter(item => item.content) : [];

      try {
        const out = await env.AI.run('@cf/google/gemma-4-26b-a4b-it', {
          messages: [
            { role: 'system', content: SYSTEM },
            ...history,
            { role: 'user', content: message }
          ],
          max_tokens: 420,
          temperature: 0.2
        });
        const answer = String(out?.response || out?.result?.response || '').trim() || 'Please contact HM Global Impact directly for this enquiry.';
        return json({ answer });
      } catch (error) {
        return json({ error: 'AI request temporarily unavailable.' }, 503);
      }
    }

    const response = await env.ASSETS.fetch(request);
    const headers = new Headers(response.headers);
    headers.set('X-Content-Type-Options', 'nosniff');
    headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');
    headers.set('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
    return new Response(response.body, { status: response.status, statusText: response.statusText, headers });
  }
};
