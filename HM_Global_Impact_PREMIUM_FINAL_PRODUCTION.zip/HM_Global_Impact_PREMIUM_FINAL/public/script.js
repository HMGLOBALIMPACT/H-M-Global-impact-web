
const menu = document.querySelector('.menu-toggle');
const navEl = document.querySelector('.nav');
if (menu && navEl) {
  menu.addEventListener('click', () => {
    const open = navEl.classList.toggle('open');
    menu.setAttribute('aria-expanded', open ? 'true' : 'false');
  });
  navEl.querySelectorAll('a').forEach(a => a.addEventListener('click', () => navEl.classList.remove('open')));
}

document.querySelectorAll('#year').forEach(el => el.textContent = new Date().getFullYear());

const revealItems = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window) {
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        observer.unobserve(entry.target);
      }
    });
  }, {threshold: 0.12});
  revealItems.forEach(el => observer.observe(el));
} else {
  revealItems.forEach(el => el.classList.add('is-visible'));
}

const slides = [...document.querySelectorAll('.hero-slide')];
const dots = [...document.querySelectorAll('.slider-dots button')];
if (slides.length) {
  let current = 0;
  const showSlide = index => {
    current = (index + slides.length) % slides.length;
    slides.forEach((s,i) => s.classList.toggle('is-active', i === current));
    dots.forEach((d,i) => d.classList.toggle('active', i === current));
  };
  dots.forEach((d,i) => d.addEventListener('click', () => showSlide(i)));
  setInterval(() => showSlide(current + 1), 5200);
}
// HM Global Impact — preliminary smart energy planner
(function(){
  const form=document.getElementById('energyPlanner');
  const result=document.getElementById('plannerResult');
  if(!form||!result) return;
  form.addEventListener('submit',function(e){
    e.preventDefault();
    const load=Math.max(100,Number(document.getElementById('loadW').value)||1000);
    const hours=Math.min(24,Math.max(1,Number(document.getElementById('hoursDay').value)||5));
    const days=Math.min(3,Math.max(.5,Number(document.getElementById('backupDays').value)||1));
    const dailyWh=load*hours;
    const inverter=Math.ceil((load*1.25)/100)*100;
    const pv=Math.ceil((dailyWh/(4.5*0.78))/100)*100;
    const batteryWh=dailyWh*days/0.85;
    const batteryKwh=(batteryWh/1000).toFixed(1);
    result.innerHTML='<strong>Preliminary estimate</strong><br>Daily energy: '+Math.round(dailyWh).toLocaleString()+' Wh<br>Suggested inverter class: about '+inverter.toLocaleString()+' W<br>PV array: about '+pv.toLocaleString()+' W<br>Battery storage: about '+batteryKwh+' kWh<br><small>Final sizing depends on appliance surge, site conditions, battery chemistry, system voltage and installation requirements.</small>';
  });
})();



/* ===== HM Global Impact AI Assistant ===== */
(function(){
  const launcher=document.createElement('button'); launcher.className='ai-launcher'; launcher.setAttribute('aria-label','Open HM Global Impact AI assistant'); launcher.title='HM Global Impact AI Assistant'; document.body.appendChild(launcher);
  const panel=document.createElement('section'); panel.className='ai-panel'; panel.setAttribute('aria-label','HM Global Impact AI Assistant');
  panel.innerHTML=`<div class="ai-head"><div><strong>HM Global AI Assistant</strong><small>Solar • Electrical • Security</small></div><button class="ai-close" aria-label="Close AI assistant">×</button></div><div class="ai-messages" id="aiMessages"><div class="ai-msg bot">Hello. I can help you understand HM Global Impact services, products, preliminary solar sizing and how to request a quotation.</div></div><div class="ai-quick"><button data-q="What solar services do you provide?">Solar services</button><button data-q="What products can I request a quote for?">Products</button><button data-q="How do I contact HM Global Impact?">Contact</button><button data-q="Help me estimate a solar system">Solar estimate</button></div><form class="ai-form" id="aiForm"><input id="aiInput" autocomplete="off" placeholder="Ask HM Global AI…"><button type="submit">Send</button></form><div class="ai-disclaimer">AI responses are informational. Product availability, pricing and final engineering decisions must be confirmed by HM Global Impact.</div>`;
  document.body.appendChild(panel);
  const messages=panel.querySelector('#aiMessages'), input=panel.querySelector('#aiInput');
  const history=[];
  function add(text,who='bot',save=true){const d=document.createElement('div');d.className='ai-msg '+who;d.textContent=text;messages.appendChild(d);messages.scrollTop=messages.scrollHeight;if(save)history.push({role:who==='user'?'user':'assistant',content:text});}
  async function ask(q){
    const prior=history.slice(-8);
    add(q,'user'); input.value='';
    const thinking=document.createElement('div');thinking.className='ai-msg bot';thinking.textContent='Thinking…';messages.appendChild(thinking);messages.scrollTop=messages.scrollHeight;
    try{
      const r=await fetch('/api/ai',{method:'POST',headers:{'content-type':'application/json'},body:JSON.stringify({message:q,history:prior})});
      if(!r.ok) throw new Error('AI endpoint unavailable');
      const data=await r.json(); thinking.remove(); add(data.answer||'Please contact HM Global Impact directly for this enquiry.');
    }catch(e){
      thinking.remove();
      const ql=q.toLowerCase();
      let a='For current pricing, stock and technical specifications, please contact HM Global Impact on +234 803 613 9930 or WhatsApp. I can also help with general solar, electrical and security questions.';
      if(ql.includes('solar')) a='HM Global Impact supports solar panels, inverters, batteries, charge controllers, system design, installation, maintenance and repairs. For a final system size, we need your loads, usage pattern and site details.';
      if(ql.includes('product')||ql.includes('price')) a='The Product Centre covers solar PV modules, inverter systems, batteries, electrical protection and PV components, with CCTV/monitoring as a catalogue category. Prices are kept as Request Quote until the exact model and current stock are confirmed.';
      if(ql.includes('contact')) a='You can call +234 803 613 9930 or use WhatsApp. Lagos: 12 Osolo Way, Ajao Estate, Isolo, Lagos State. Ibadan: 120 Ifesowapo Oleyo Street, From Tipper Garage, Ibadan, Oyo State.';
      add(a);
    }
  }
  launcher.addEventListener('click',()=>panel.classList.toggle('open'));
  panel.querySelector('.ai-close').addEventListener('click',()=>panel.classList.remove('open'));
  panel.querySelectorAll('.ai-quick button').forEach(b=>b.addEventListener('click',()=>ask(b.dataset.q)));
  panel.querySelector('#aiForm').addEventListener('submit',e=>{e.preventDefault();const q=input.value.trim();if(q)ask(q)});
})();

/* Product quote buttons */
document.querySelectorAll('.quote-mini').forEach(btn=>btn.addEventListener('click',()=>{
  const product=btn.dataset.product||'product';
  const msg=encodeURIComponent(`Hello HM Global Impact, I would like to request a quotation for ${product}. Please share current price, available models/specification and delivery/installation options.`);
  window.open('https://wa.me/2348036139930?text='+msg,'_blank','noopener');
}));

/* Back-to-top control */
(function(){const b=document.createElement('button');b.className='backtop';b.textContent='↑';b.setAttribute('aria-label','Back to top');document.body.appendChild(b);window.addEventListener('scroll',()=>b.classList.toggle('show',scrollY>600));b.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));})();
