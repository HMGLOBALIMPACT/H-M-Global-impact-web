HM GLOBAL IMPACT — FINAL PRODUCTION WEBSITE PACKAGE

This package is the final production candidate for the HM Global Impact website.

Includes:
- Clean transparent original HM Global logo rebuilt from the supplied source image
- Responsive multi-page corporate website
- Solar, electrical and security service pages
- Commercial product centre with Request Quote workflow
- Real security/CCTV image in the security solution section
- Real inverter imagery in the hero and product presentation
- Preliminary solar sizing planner
- HM Global AI Assistant powered by Cloudflare Workers AI
- Multi-turn AI context, guarded company facts and fallback responses
- WhatsApp, phone and email enquiry paths
- SEO metadata, Organization structured data, sitemap, robots.txt and web manifest
- Accessibility and reduced-motion support
- Production security response headers

Cloudflare deployment:
- Worker name: h-m-global-impact-web
- Build command must extract this package and copy the inner project to the root before `npx wrangler deploy`.
- Workers AI binding name: AI
- Static assets binding: ASSETS

Recommended build command for the current GitHub repository:
unzip -o HM_Global_Impact_PREMIUM_FINAL_PRODUCTION.zip && cp -R HM_Global_Impact_PREMIUM_FINAL/. . && sed -i 's/"name": "red-frost-3947"/"name": "h-m-global-impact-web"/' wrangler.jsonc

Do not delete the existing old Worker until the new Worker is connected to the production domain and tested.
